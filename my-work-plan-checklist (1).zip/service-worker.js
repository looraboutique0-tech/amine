const CACHE_NAME = 'work-plan-cache-v1';

// On install, cache the core assets.
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      // We don't know the final JS bundle names, so we can't pre-cache them.
      // The fetch handler will cache assets dynamically as they are requested.
      return cache.addAll([
        '/',
        '/index.html'
      ]);
    })
  );
});

// On fetch, use a cache-first strategy.
self.addEventListener('fetch', (event) => {
  // We only want to cache GET requests.
  if (event.request.method !== 'GET') {
    return;
  }
  
  // For requests to external CDNs (like aistudiocdn), just fetch from network.
  if (event.request.url.includes('aistudiocdn.com')) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      // Return the cached response if it exists.
      if (cachedResponse) {
        return cachedResponse;
      }

      // If not in cache, fetch from the network.
      return fetch(event.request).then((networkResponse) => {
        // Check if we received a valid response
        if (!networkResponse || networkResponse.status !== 200) {
            return networkResponse;
        }

        // Clone the response stream.
        const responseToCache = networkResponse.clone();

        // Cache the new response.
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, responseToCache);
        });

        // Return the network response.
        return networkResponse;
      });
    })
  );
});

// On activate, clean up old caches.
self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});