import React, { useState, useCallback, useMemo } from 'react';
import { Task } from './types';
import TaskItem from './components/TaskItem';
import { PlusIcon } from './components/icons/PlusIcon';

// Helper function to find and update a task in a nested structure
const findTaskAndApply = (tasks: Task[], id: string, updater: (task: Task) => Task): Task[] => {
  return tasks.map(task => {
    if (task.id === id) {
      return updater(task);
    }
    if (task.subtasks && task.subtasks.length > 0) {
      const newSubtasks = findTaskAndApply(task.subtasks, id, updater);
      if (newSubtasks !== task.subtasks) {
        return { ...task, subtasks: newSubtasks };
      }
    }
    return task;
  }).filter(Boolean) as Task[];
};

// Helper function to find and delete a task
const findTaskAndDelete = (tasks: Task[], id: string): Task[] => {
  return tasks.reduce((acc, task) => {
    if (task.id === id) {
      return acc; // Skip adding this task
    }
    if (task.subtasks && task.subtasks.length > 0) {
      acc.push({ ...task, subtasks: findTaskAndDelete(task.subtasks, id) });
    } else {
      acc.push(task);
    }
    return acc;
  }, [] as Task[]);
};

// Helper function to count tasks
const countTasks = (tasks: Task[]): { total: number; completed: number } => {
    let total = 0;
    let completed = 0;
    const counter = (taskList: Task[]) => {
        for (const task of taskList) {
            total++;
            if (task.completed) {
                completed++;
            }
            if (task.subtasks && task.subtasks.length > 0) {
                counter(task.subtasks);
            }
        }
    };
    counter(tasks);
    return { total, completed };
};

const App: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [newTaskText, setNewTaskText] = useState<string>('');

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;

    const newTask: Task = {
      id: `${Date.now()}`,
      text: newTaskText,
      completed: false,
      subtasks: [],
      content: '',
    };
    setTasks(prevTasks => [...prevTasks, newTask]);
    setNewTaskText('');
  };

  const addSubtask = useCallback((parentId: string, text: string) => {
    const newSubtask: Task = {
      id: `${Date.now()}`,
      text,
      completed: false,
      subtasks: [],
      content: '',
    };
    const updater = (task: Task) => ({
      ...task,
      subtasks: [...(task.subtasks || []), newSubtask],
    });
    setTasks(currentTasks => findTaskAndApply(currentTasks, parentId, updater));
  }, []);

  const toggleTask = useCallback((id: string) => {
    const updater = (task: Task) => ({ ...task, completed: !task.completed });
    setTasks(currentTasks => findTaskAndApply(currentTasks, id, updater));
  }, []);

  const deleteTask = useCallback((id: string) => {
    setTasks(currentTasks => findTaskAndDelete(currentTasks, id));
  }, []);
  
  const updateTaskContent = useCallback((id: string, content: string) => {
    const updater = (task: Task) => ({ ...task, content });
    setTasks(currentTasks => findTaskAndApply(currentTasks, id, updater));
  }, []);

  const { total: totalTasks, completed: completedTasks } = useMemo(() => countTasks(tasks), [tasks]);
  const progress = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-gray-900 text-white font-sans flex items-center justify-center p-4 overflow-hidden">
      <div className="w-full max-w-2xl transform perspective-[1500px] rotate-x-[-3deg] rotate-y-[4deg] transition-transform duration-500 hover:rotate-x-0 hover:rotate-y-0">
        <main className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-2xl shadow-black/30 p-8">
          <header className="text-center mb-8">
            <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-purple-400 to-pink-500 text-transparent bg-clip-text">
              My Work Plan
            </h1>
            <p className="text-slate-400 mt-2">
              Organize your goals into tasks and sub-tasks.
            </p>
          </header>

          <form onSubmit={handleAddTask} className="mb-8">
            <div className="relative">
              <input
                type="text"
                value={newTaskText}
                onChange={(e) => setNewTaskText(e.target.value)}
                placeholder="Add a new main task..."
                className="w-full bg-slate-900/70 border border-slate-700 rounded-lg py-3 pl-4 pr-32 text-lg focus:ring-2 focus:ring-purple-500 focus:outline-none transition-shadow duration-300 shadow-inner"
              />
              <button
                type="submit"
                disabled={!newTaskText.trim()}
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-semibold py-2 px-5 rounded-md flex items-center gap-2 transition-all duration-300 ease-in-out transform hover:scale-105 active:scale-100 disabled:opacity-50 disabled:cursor-not-allowed disabled:scale-100"
              >
                <PlusIcon />
                Add
              </button>
            </div>
          </form>
          
          <div className="space-y-4 min-h-[200px]">
            {tasks.length > 0 ? (
                <>
                    <div className="w-full bg-slate-900/50 rounded-full h-2.5 mb-4 border border-slate-700">
                        <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-full rounded-full transition-all duration-500 ease-out" style={{ width: `${progress}%` }}></div>
                    </div>
                    {tasks.map(task => (
                        <TaskItem
                            key={task.id}
                            task={task}
                            onToggle={toggleTask}
                            onDelete={deleteTask}
                            onAddSubtask={addSubtask}
                            onUpdateTaskContent={updateTaskContent}
                            level={0}
                        />
                    ))}
                </>
            ) : (
              <div className="text-center text-slate-500 py-10">
                <p>Add a task to start your work plan.</p>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;