
import { GoogleGenAI, Type } from "@google/genai";

if (!process.env.API_KEY) {
    console.error("API_KEY is not set in environment variables.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const planSchema = {
    type: Type.OBJECT,
    properties: {
        tasks: {
            type: Type.ARRAY,
            description: "A list of actionable tasks to achieve the goal.",
            items: {
                type: Type.STRING,
                description: "A single, specific, and actionable step. Start with an action verb."
            },
        },
    },
    required: ["tasks"],
};

export const generatePlan = async (goal: string): Promise<string[]> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Create a detailed, actionable checklist for the following goal: "${goal}"`,
            config: {
                systemInstruction: "You are an expert project manager. Your role is to break down a user's high-level goal into a concise, actionable checklist of 5 to 10 steps. Each step should be clear and start with an action verb.",
                responseMimeType: "application/json",
                responseSchema: planSchema,
            },
        });

        const jsonText = response.text.trim();
        const parsedJson = JSON.parse(jsonText);

        if (parsedJson && Array.isArray(parsedJson.tasks)) {
            return parsedJson.tasks;
        } else {
            throw new Error("AI response did not contain a valid 'tasks' array.");
        }

    } catch (error) {
        console.error("Error generating plan with Gemini:", error);
        throw new Error("Failed to generate plan. The AI may be experiencing issues or the request was malformed.");
    }
};
