import React, { useState } from 'react';
import { Task } from '../types';
import { TrashIcon } from './icons/TrashIcon';
import { PlusIcon } from './icons/PlusIcon';

interface TaskItemProps {
  task: Task;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onAddSubtask: (parentId: string, text: string) => void;
  onUpdateTaskContent: (id: string, content: string) => void;
  level: number;
}

const TaskItem: React.FC<TaskItemProps> = ({ task, onToggle, onDelete, onAddSubtask, onUpdateTaskContent, level }) => {
  const [newSubtaskText, setNewSubtaskText] = useState('');
  const [showSubtaskInput, setShowSubtaskInput] = useState(false);

  const handleAddSubtask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubtaskText.trim()) return;
    onAddSubtask(task.id, newSubtaskText);
    setNewSubtaskText('');
    setShowSubtaskInput(false);
  };

  const indentStyle = { marginLeft: `${level * 2}rem` };

  return (
    <div style={indentStyle} className="task-container transition-all duration-300">
        <div className={`flex items-center gap-4 bg-slate-900/50 p-4 rounded-lg border border-slate-700/50 shadow-lg transition-all duration-300 ease-in-out ${task.completed ? 'opacity-50' : 'opacity-100'}`}>
            <div className="flex-shrink-0">
                <input
                    type="checkbox"
                    checked={task.completed}
                    onChange={() => onToggle(task.id)}
                    className="appearance-none h-6 w-6 border-2 border-slate-600 rounded-md checked:bg-gradient-to-br checked:from-purple-500 checked:to-pink-500 checked:border-transparent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-purple-500 transition-all duration-200 cursor-pointer"
                />
            </div>
            <p className={`flex-grow text-slate-300 transition-colors duration-300 ${task.completed ? 'line-through text-slate-500' : ''}`}>
                {task.text}
            </p>
            {level < 2 && ( // Limit nesting depth 
                <button
                    onClick={() => setShowSubtaskInput(!showSubtaskInput)}
                    className="text-slate-500 hover:text-purple-400 transition-colors duration-200 transform hover:scale-110"
                    aria-label="Add sub-task"
                >
                    <PlusIcon />
                </button>
            )}
            <button
                onClick={() => onDelete(task.id)}
                className="text-slate-500 hover:text-red-500 transition-colors duration-200 transform hover:scale-110"
                aria-label="Delete task"
            >
                <TrashIcon />
            </button>
        </div>

        <div className="pl-10 pr-4 pt-2 pb-2">
            <textarea
                value={task.content || ''}
                onChange={(e) => onUpdateTaskContent(task.id, e.target.value)}
                placeholder="Ajouter un contenu..."
                className="w-full bg-slate-800/70 border border-slate-600 rounded-md py-2 px-3 text-sm text-slate-300 focus:ring-1 focus:ring-purple-500 focus:outline-none resize-y transition-shadow duration-300 shadow-inner"
                rows={2}
            />
        </div>

        {showSubtaskInput && (
            <form onSubmit={handleAddSubtask} className="mt-2 ml-10 flex gap-2 animate-fade-in">
                <input
                    type="text"
                    value={newSubtaskText}
                    onChange={(e) => setNewSubtaskText(e.target.value)}
                    placeholder="Add a new sub-task..."
                    className="flex-grow bg-slate-800/70 border border-slate-600 rounded-md py-1 px-2 text-sm focus:ring-1 focus:ring-purple-500 focus:outline-none"
                    autoFocus
                />
                <button type="submit" className="bg-purple-600 text-white px-3 py-1 text-sm rounded-md hover:bg-purple-700 transition-colors">Add</button>
            </form>
        )}

        <div className="mt-2 space-y-2">
            {task.subtasks && task.subtasks.map(subtask => (
                <TaskItem
                    key={subtask.id}
                    task={subtask}
                    onToggle={onToggle}
                    onDelete={onDelete}
                    onAddSubtask={onAddSubtask}
                    onUpdateTaskContent={onUpdateTaskContent}
                    level={level + 1}
                />
            ))}
        </div>
    </div>
  );
};

export default TaskItem;